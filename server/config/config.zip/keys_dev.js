module.exports = {
  type: "service_account",
  project_id: "eiq-test",
  private_key_id: "f4775b164a164329c934694c577b3b89c843c849",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEugIBADANBgkqhkiG9w0BAQEFAASCBKQwggSgAgEAAoIBAQCbwmuaOHXxb1jD\n5GjnRppr8vZilHTyOhxcN9kKzgKpH70n6AmwykfMv8IChtIGBRWxLSSxJ6UU6Y6k\nsgXldIV+FFhWMd5JFiidrX5C5Bd1ttNQ5obzmD8t5Q/+URGKkihXZH8BmUWP1F+R\nZolVXHSEk+CX4CQEjljV4xYWwnEW5+hjlJsCSqYocyFdiSRyJ3DK5rTZ9dFGCu4m\nOgMxNdfn8rc9mOQ5Y9t+YPYYVF3iNwG7UvuUhx5P4n1f2HV2IVZ1TgKyHuhM9W/s\nAUO9gVmFg6yJcoRZu0DkfkSp34iEm0dJ6jHDmmj1iG5aA9f4lnqNPmEl2r/DNSvd\nBdJrl2S/AgMBAAECggEAASCUV30WBYfxtL9hWqNvhow1inPPjX7xBdKRA/xuBHmx\ngwvaBWtxKTgtIj1T9ss2szuHASYliOqWr4Lq9J3KTkUnf1dSfdjlOC9n/7Utc2jg\nTwGRX0TZ6qS2cq/+gzNcAgqwe2cBHwK8172oie7YmGYQEb+QATfmXoUIX69tnbua\nrAjIbToriKeBsQJxbmmiO1oXc3FkXuUxKwtEG0LL9OCNxtXp+2fIBcTdy254y70s\nQJZRIdb7Dz5j8REun3cBSO9/tWj0dd64fFmwMu7RXGd1g6VxygeUsXJDJDV277ip\n7UuztQ0DKFSMnnfBuoX7cUtCmHtt+itR/j7XltUuLQKBgQDV6K0/sKXBtQLhodrI\nM5Q5RMyxXa7k7M+uRFVulXA99B6USGPDYbod0abMJKxZz21tfgf4jxuNTsA/TXQv\niutYOwsUTjYTs93ClFJ8Kjeb4ZNnpO4BgY984cnQSB+gYALYY657T/X8h/KJi1N2\nUH8S5OM9SgVkWEBln3y7FfSsrQKBgQC6aI6oJaLgJhpDjHQxWpzmdzdFvGtbfBHi\ny4yPxOqj6okfR2Nhfb1+TrH2B2P92fKVhVSQBnVec2aYzbSyXAuxZKfHFbDi3tg7\nBKPx8EWS2uKGBolpAPBJmcG0BUWz9uufxHaHgMEAsnzjohOKgXV2b9nEnZ/9ugS6\nO1+RZgE4mwKBgGDtDZPOd01Ot/+FV51fwcoxYo775EPXCkPssslo7XMlKrYGFy5x\nGeRpGytlcrM/SlZSxUnbjqB5DqOgdQUV7Y4NMvgAeIB1AAcrLjUU7B22GRTdpvsH\nufzcUpYOGEaTOrbSdD1r/gpvj3bDqw3xa6MkE9Oxtr/BPWzO17XuPPABAoGAHuI3\n0G/73jsx2sModQzYNe7Gf41KFCwoInUq4p7zaRjwgvgm5P4aKRUMswBidqpnYJJo\ngjwvsehYtTRPncVWQpu0mG1lkxDsrkqEhw8R19Tf9uiaV4VKSkdpKlQ9SiW8wAmi\nwax5TY5E1soBhs8QEQFTCRo8aaMqKViw6rwFs8UCfwpjye1SK42puJFcfL0e5gTg\n0DgzSz+rh4vs85fHbogMr7P1fimeia5GZhc7W8Bnq4DE5Hnozi4zTDYKtaXcEKhB\nAz/t1ZCR015IpfJBxjdtirPWefGrfJtI15r9JQlWAlCgx98oaRqGGIbwfcOqsOQ4\n6QoxvsD3v/prHgpDVo4=\n-----END PRIVATE KEY-----\n",
  client_email: "eiq-test@eiq-test.iam.gserviceaccount.com",
  client_id: "113687688038701060908",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/eiq-test%40eiq-test.iam.gserviceaccount.com",
  secretOrKey: "secret",
  googleClientId:
    "650912419131-qgbkqr2h9o7lt2440g4u63etal0aj9q7.apps.googleusercontent.com",
  googleClientSecret: "RWfRv3uOblDotMeGzfde_y9b",
  googleCallbackURL: "/api/users/google/redirect",
  googleUserProfileURL: "https://www.googleapis.com/oauth2/v3/userinfo",
  defaultGooglePassword: "some dummy password"
};
